const CustomMenu = (props) => {
	return <h6>Custom Menu</h6>;
};

export default CustomMenu;
