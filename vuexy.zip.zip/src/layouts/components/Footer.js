const CustomFooter = () => {
	return <h6>Custom Footer</h6>;
};

export default CustomFooter;
