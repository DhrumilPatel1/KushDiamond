// ** Navigation sections imports
import apps from './apps';
import dashboards from './dashboards';

// ** Merge & Export
export default [...dashboards, ...apps];
